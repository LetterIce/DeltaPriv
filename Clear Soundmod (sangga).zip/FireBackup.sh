#!/sbin/sh
# Fire Backup script by K®ISH

mkdir /data/media/0/FireBackup
cp /system/etc/audio_effects.conf /data/media/0/FireBackup
cp /system/vendor/etc/audio_effects.conf /data/media/0/FireBackup
cp /system/build.prop /data/media/0/FireBackup
exit 0;