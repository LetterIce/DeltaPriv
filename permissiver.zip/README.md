# Selinux Permissive by @Edzamber


This is a simple Magisk module to force Kernel to permissive on postdatafs mode.
